import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css']
})
export class CustomerComponent {

  public cname:string[];
  public message="test message";
  public constructor(){
   this.cname=["ajay","vijay","rohit"]
  }

}
