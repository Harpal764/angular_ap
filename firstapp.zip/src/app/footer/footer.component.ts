import {Component} from '@angular/core';
@Component({
    selector:'app-footer',
    // template:`<div>footer page</div>`,
    // styles:['div{height:120px;background:green;}']
    templateUrl:'./footer.component.html',
    styleUrls:['./footer.component.css']
})
export class FooterComponent{

}